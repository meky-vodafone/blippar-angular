import {
  Component,
  CUSTOM_ELEMENTS_SCHEMA,
  ElementRef,
  signal,
  viewChild,
  WritableSignal,
} from '@angular/core';
// Import A-Frame and its components (from npm)
import 'aframe';
import 'aframe-extras';
import 'aframe-environment-component';
import { environment } from 'src/environments/environment';
import { ConsoleLogComponent } from "../console-log-component/console-log.component";

@Component({
  selector: 'app-blipp-ar-aframe',
  imports: [ConsoleLogComponent],
  templateUrl: './blipp-ar.component.html',
  styleUrl: './blipp-ar.component.scss',
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class BlippArComponent {
  private webarLoaded = false;
  arModelRef = viewChild<ElementRef>('ar_model');

  modelPath = environment.yougoAR_Game_BaseUrl + 'assets/models/yougo_1.glb';
  scriptPath =
    environment.yougoAR_Game_BaseUrl + 'assets/blippar-webar-sdk/webar-sdk/webar-sdk-v2.0.8.min.js';

  ngAfterViewInit(): void {
    this._requestMotionPermission().then((permissionGranted) => {
      if (!permissionGranted) {
        console.error('Motion permission denied ❌');
        return;
      }

      this.loadBlipparWebSDK();
    });
  }

  private loadBlipparWebSDK(): void {
    if (!this.webarLoaded) {
      const script = document.createElement('script');
      script.src = this.scriptPath;

      script.async = true;

      // Set all the attributes
      script.setAttribute('webar-mode', 'surface-tracking');
      script.setAttribute('auto-init', 'false');
      script.setAttribute('auto-start', 'true');
      script.setAttribute('minimal-ui', 'true');

      script.onload = () => {
        this.webarLoaded = true;
        console.log('WEBAR SDK loaded:', (window as any).WEBARSDK);
        this.initWebAR();
      };
      document.body.appendChild(script);
    } else {
      this.initWebAR();
    }
  }

  private initWebAR(): void {
    const WEBARSDK = (window as any).WEBARSDK;
    if (!WEBARSDK) {
      console.error('WEBARSDK is not loaded yet.');
      return;
    }
    WEBARSDK.Init();
    // Explicitly start the SDK to ensure splash progresses and camera starts
    if (typeof WEBARSDK.Start === 'function') {
      try {
        WEBARSDK.Start();
      } catch (e) {
        console.warn('WEBARSDK.Start() threw an error', e);
      }
    }

    WEBARSDK.SetGuideViewCallbacks(
      () => console.log('Start guide animation'),
      () => console.log('Stop guide animation')
    );

    WEBARSDK.SetVideoStartedCallback(() => {
      const deskenv = document.getElementById('deskenv');
      deskenv?.parentNode?.removeChild(deskenv);
    });

    WEBARSDK.SetARModelPlaceCallback(() => {
      console.log('AR model placed');
    });

    WEBARSDK.SetResetButtonCallback(() => {
      console.log('Reset button clicked');
    });

    this.listenToModelClick();
  }

  private listenToModelClick(): void {
    const model = this.arModelRef().nativeElement;

    model.addEventListener('model-loaded', () => {
      console.log('Model loaded and ready for interaction.');

      // Unified handler function
      const handleInteraction = (event) => {
        event.stopPropagation();
        event.preventDefault();

        console.log('Astronaut interacted:', event.type);

        // model.setAttribute("scale", {
        //   x: 0,
        //   y: 0,
        //   z: 0,
        // });
        model.setAttribute('visible', 'false');
      };

      // Handle both click and touchstart
      model.addEventListener('click', handleInteraction);
      model.addEventListener('touchstart', handleInteraction);
    });
  }

  private async _requestMotionPermission(): Promise<boolean> {
    // Request Motion Permission (iOS only)
    if (
      typeof DeviceMotionEvent !== 'undefined' &&
      //@ts-ignore
      typeof DeviceMotionEvent.requestPermission === 'function'
    ) {
      try {
        //@ts-ignore
        const response = await DeviceMotionEvent.requestPermission();
        console.log('INFO', 'Motion permission: ' + response);
        if (response !== 'granted') {
          console.error('Motion permission denied ❌');
          return false;
        }
      } catch (err) {
        console.error('Motion permission error: ' + err);
        return false;
      }
    } else {
      console.log('INFO', 'No motion permission API needed (non-iOS)');
    }
    return true;
  }
}
