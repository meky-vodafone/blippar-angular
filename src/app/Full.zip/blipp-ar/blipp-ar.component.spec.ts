import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BlippArComponent } from './blipp-ar.component';

describe('BlippArComponent', () => {
  let component: BlippArComponent;
  let fixture: ComponentFixture<BlippArComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [BlippArComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BlippArComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
