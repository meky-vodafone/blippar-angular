import { Component, CUSTOM_ELEMENTS_SCHEMA, ElementRef, viewChild } from '@angular/core';
import 'aframe';
import 'aframe-extras';
import 'aframe-environment-component';
import { environment } from 'src/environments/environment';
@Component({
  selector: 'app-aframe-scene',
  imports: [],
  templateUrl: './aframe-scene.component.html',
  styleUrl: './aframe-scene.component.scss',
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class AframeSceneComponent {
  modelPath = environment.yougoAR_Game_BaseUrl + 'assets/models/yougo_1.glb';
  arModelRef = viewChild<ElementRef>('ar_model');

  ngAfterViewInit() {
    const model = this.arModelRef().nativeElement;
    if (!model) return;

    model.addEventListener('model-loaded', () => {
      console.log('Model loaded and ready for interaction.');

      // Unified handler function
      const handleInteraction = (event) => {
        event.stopPropagation();
        event.preventDefault();

        console.log('Model Clicked');

        // model.setAttribute("scale", {
        //   x: 0,
        //   y: 0,
        //   z: 0,
        // });
        model.setAttribute('visible', false);
      };

      // Handle both click and touchstart
      model.addEventListener('click', handleInteraction);
      model.addEventListener('touchstart', handleInteraction);
    });
  }
}
