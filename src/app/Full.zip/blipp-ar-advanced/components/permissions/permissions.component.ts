import { Component, inject, signal } from '@angular/core';
import { BlipparService } from '../../service/blippar.service';

@Component({
  selector: 'app-permissions',
  imports: [],
  templateUrl: './permissions.component.html',
  styleUrl: './permissions.component.scss',
})
export class PermissionsComponent {
  private blipparService = inject(BlipparService);
  sdk_loading = signal(false);
  error = signal<boolean>(false);
  showPermissionBtn = signal(true);

  async askForMotionPermission() {
    const isIos = this.blipparService.isiOSChecker();
    // 1. Request motion permissions (iOS only)
    if (isIos && typeof (window as any).DeviceMotionEvent?.requestPermission === 'function') {
      try {
        const permission = await (window as any).DeviceMotionEvent.requestPermission();
        if (permission !== 'granted') {
          this.error.set(true);
          return;
        } else {
          this.blipparService
            .askForPermissions()
            .then(() => {
              this.goToGame();
            })
            .catch(() => {
              this.error.set(true);
            });
        }
      } catch (error) {
        this.error.set(true);
        return;
      }
    } else {
      this.blipparService
        .askForPermissions()
        .then(() => {
          this.goToGame();
        })
        .catch(() => {
          this.error.set(true);
        });
    }

    // this.blipparService.askForPermissions().then(() => {
    //   this.showPermissionBtn.set(false);
    //   this.sdk_loading.set(true);
    //   this.blipparService.injectBlipparWebSDKtoDOM().subscribe({
    //     next: () => {
    //       console.log('Blippar WebAR SDK script loaded successfully.');
    //       this.blipparService.currentState.set('game');
    //     },
    //     error: (err) => {
    //       this.sdk_loading.set(false);
    //       this.error.set(true);
    //       console.error('Error loading Blippar WebAR SDK script:', err);
    //       this.blipparService.currentState.set('error');
    //     },
    //     complete: () => {
    //       this.sdk_loading.set(false);
    //     },
    //   });
    // }).catch((err) => {
    //   console.error('Error obtaining permissions:', err);
    //   this.error.set(true);
    //   this.blipparService.currentState.set('error');
    // });
  }
  private goToGame(): void {
    this.showPermissionBtn.set(false);
    this.sdk_loading.set(true);
    this.blipparService.injectBlipparWebSDKtoDOM().subscribe({
      next: () => {
        console.log('Blippar WebAR SDK script loaded successfully.');
        this.blipparService.currentState.set('game');
        this.sdk_loading.set(false);
      },
      error: (err) => {
        this.sdk_loading.set(false);
        this.error.set(true);
        console.error('Error loading Blippar WebAR SDK script:', err);
        this.blipparService.currentState.set('error');
      },
      complete: () => {
        this.sdk_loading.set(false);
      },
    });
  }
}
