import { DatePipe } from '@angular/common';
import { Component, computed, inject, output, signal } from '@angular/core';

@Component({
  selector: 'app-game-header',
  imports: [DatePipe],
  templateUrl: './game-header.component.html',
  styleUrl: './game-header.component.scss',
})
export class GameHeaderComponent {
  time = 60;
  secondsLeft = signal(this.time);
  progressBarWidth = computed(() => ((this.time - this.secondsLeft()) * 100) / this.time);
  private intervalId?: ReturnType<typeof setInterval>;

  onTimerComplete = output();

  ngOnInit() {
    this.startTimer();
  }

  _onTimerComplete(): void {
    this.onTimerComplete.emit();
    console.log('Complete');
  }

  private startTimer() {
    this.intervalId = setInterval(() => {
      const current = this.secondsLeft();
      if (current > 0) {
        this.secondsLeft.set(current - 1);
      } else {
        clearInterval(this.intervalId);
        this._onTimerComplete();
      }
    }, 1000);
  }

  ngOnDestroy() {
    clearInterval(this.intervalId);
  }
}
