import {
  Component,
  CUSTOM_ELEMENTS_SCHEMA,
  ElementRef,
  inject,
  signal,
  viewChild,
} from '@angular/core';
import { environment } from 'src/environments/environment';
import 'aframe';
import 'aframe-extras';
import 'aframe-environment-component';
import { BlipparService } from './service/blippar.service';
import { PermissionsComponent } from './components/permissions/permissions.component';
import { AframeSceneComponent } from './components/aframe-scene/aframe-scene.component';
import { GameHeaderComponent } from './components/game-header/game-header.component';
@Component({
  selector: 'app-blipp-ar-advanced',
  imports: [PermissionsComponent, AframeSceneComponent, GameHeaderComponent],
  templateUrl: './blipp-ar-advanced.component.html',
  styleUrl: './blipp-ar-advanced.component.scss',
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class BlippArAdvancedComponent {
  // showGame = signal(false);
  blipparService = inject(BlipparService);
  loading = signal(false);
  currentState = this.blipparService.currentState;
  refreshPage(): void {
    window.location.reload();
  }
}
