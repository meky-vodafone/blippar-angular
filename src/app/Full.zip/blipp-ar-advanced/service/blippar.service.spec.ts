import { TestBed } from '@angular/core/testing';

import { BlipparService } from './blippar.service';

describe('BlipparService', () => {
  let service: BlipparService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BlipparService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
