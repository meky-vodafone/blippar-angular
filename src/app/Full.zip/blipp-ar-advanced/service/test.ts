import { Injectable, signal } from '@angular/core';
import { Observable } from 'rxjs';
import { StorageService } from 'src/app/core/services/storage/storage.service';
import { StorageType } from 'src/app/shared/enums/storage.enum';
import { environment } from 'src/environments/environment';

const CAMERA_CONFIG = {
  // Camera constraints for optimal AR performance
  VIDEO_CONSTRAINTS: {
    facingMode: 'environment', // Use rear camera
    advanced: [
      {
        focusMode: 'manual',
        focusDistance: 0,
      },
    ],
    deviceId: undefined,
  },

  // Timing settings
  TIMING: {
    GYRO_CHECK_DELAY: 500, // ms to wait before checking gyro
    SDK_RETRY_INTERVAL: 250, // ms between SDK initialization retries
    VIDEO_TRANSITION_DELAY: 800, // ms before hiding loading screen
  },
};

@Injectable({
  providedIn: 'root',
})
export class BlipparService {
  scriptPath =
    environment.yougoAR_Game_BaseUrl + 'assets/blippar-webar-sdk/webar-sdk/webar-sdk-v2.0.8.min.js';
  error = signal(null);
  isIOS: boolean = false;
  private cameraStream: MediaStream | null = null;
  private videoElement: HTMLVideoElement | null;
  constructor(private storageService: StorageService) {
    this.isiOSChecker();
  }

  public injectBlipparWebSDKtoDOM(): Observable<void> {
    return new Observable((observer) => {
      const script = document.createElement('script');
      script.src = this.scriptPath;
      script.async = true;

      // Set all the attributes
      script.setAttribute('webar-mode', 'surface-tracking');
      // script.setAttribute('on-progress', 'customProgressCallback');
      // script.setAttribute('on-error', 'customErrorCallback');
      script.setAttribute('auto-init', 'true');
      script.setAttribute('auto-start-tracking', 'true');
      script.setAttribute('minimal-ui', 'true');
      script.setAttribute('render-scene-on-desktop', 'false');
      script.setAttribute('external-camera-stream', 'true');
      script.setAttribute('debug-mode', 'true');
      script.onload = () => {
        observer.next();
        observer.complete();
      };
      script.onerror = () => {
        this.error.set('Failed to load Blippar Web SDK');
        observer.error(this.error);
      };
      document.head.appendChild(script);
    });
  }

  public initializeCameraPermissions() {
    if (this.isIOS) {
      console.log('🍎 iOS detected - showing camera permission prompt');
      showCameraPermissionDialog();
    } else {
      console.log('🤖 Non-iOS platform - requesting camera access directly');
      startCameraStream();
    }
  }
  private isiOSChecker() {
    let ua = navigator.userAgent.toLowerCase();
    if (this.storageService.getStorage('Platform', StorageType.cookiesStorage)) {
      ua = this.storageService.getStorage('Platform', StorageType.cookiesStorage).toLowerCase();
    }
    this.isIOS = ua.indexOf('iphone') > -1; // ios check
  }

  /**
   * Start camera stream with optimal settings for AR
   */
  async startCameraStream() {
    console.log('🎥 Starting camera stream...');

    if (!navigator.mediaDevices?.getUserMedia) {
      console.error('❌ getUserMedia not supported in this browser');
      return;
    }

    try {
      // Get available video input devices
      const devices = await navigator.mediaDevices.enumerateDevices();
      const videoDevices = devices.filter((device) => device.kind === 'videoinput');

      if (videoDevices.length > 0) {
        console.log(`📹 Found ${videoDevices.length} video device(s)`);

        // Use the last camera (usually rear camera on mobile)
        const selectedDevice = videoDevices[videoDevices.length - 1];
        console.log('📱 Selected camera:', selectedDevice.label || 'Unknown camera');

        // Add device ID to constraints if available
        if (selectedDevice.deviceId) {
          CAMERA_CONFIG.VIDEO_CONSTRAINTS.deviceId = selectedDevice.deviceId;
        }
      }

      // Request camera stream
      const stream = await navigator.mediaDevices.getUserMedia({
        // @ts-ignore
        video: CAMERA_CONFIG.VIDEO_CONSTRAINTS,
      });

      console.log('✅ Camera stream started successfully');
      this.cameraStream = stream;

      // Assign stream to video element
      if (this.videoElement) {
        this.videoElement.srcObject = stream;
      }

      // Wait a bit then check motion sensor permissions
      setTimeout(() => this.initializeMotionPermissions(), CAMERA_CONFIG.TIMING.GYRO_CHECK_DELAY);
    } catch (error) {
      console.error('❌ Failed to start camera:', error);
      this.handleCameraError(error);
    }
  }
  /**
   * Handle camera stream errors
   */
  handleCameraError(error) {
    console.error('Camera error details:', error);

    // You could implement custom error handling here
    // For now, we'll just log the error
    if (error.name === 'NotAllowedError') {
      console.error('Camera permission denied');
    } else if (error.name === 'NotFoundError') {
      console.error('No camera found');
    } else if (error.name === 'NotReadableError') {
      console.error('Camera is in use by another application');
    }
  }
  /**
   * Initialize motion sensor permissions after camera is ready
   */
  initializeMotionPermissions() {
    console.log('🧭 Checking motion sensor permissions...');
    //@ts-ignore
    if (typeof DeviceMotionEvent?.requestPermission === 'function') {
      // iOS 13+ requires explicit permission
      console.log('📱 iOS 13+ detected - showing motion permission prompt');
      showMotionPermissionDialog();
    } else {
      // Check if we already have motion data
      if (hasGyroPermission) {
        console.log('✅ Motion sensors already available');
        hideMotionPermissionDialog();
        initializeSDK();
      } else {
        console.log('⏳ Waiting for motion sensor data...');
        // Will be handled by event listeners set up in initializeGyroPermissions()
      }
    }
  }
}
