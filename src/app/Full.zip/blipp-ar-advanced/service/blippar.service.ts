import { Injectable, signal } from '@angular/core';
import { Observable } from 'rxjs';
import { StorageService } from 'src/app/core/services/storage/storage.service';
import { StorageType } from 'src/app/shared/enums/storage.enum';
import { environment } from 'src/environments/environment';

// Declare the global WEBARSDK variable
declare var WEBARSDK: any;

const CAMERA_CONFIG = {
  // Camera constraints for optimal AR performance
  VIDEO_CONSTRAINTS: {
    facingMode: 'environment', // Use rear camera
    advanced: [
      {
        focusMode: 'manual',
        focusDistance: 0,
      },
    ],
    deviceId: undefined,
  },

  // Timing settings
  TIMING: {
    GYRO_CHECK_DELAY: 500, // ms to wait before checking gyro
    SDK_RETRY_INTERVAL: 250, // ms between SDK initialization retries
    VIDEO_TRANSITION_DELAY: 800, // ms before hiding loading screen
  },
};

@Injectable({
  providedIn: 'root',
})
export class BlipparService {
  currentState = signal<'permissions' | 'game' | 'error' | 'game-ended'>('permissions');
  SDK_Loaded = signal(false);
  scriptPath =
    environment.yougoAR_Game_BaseUrl + 'assets/blippar-webar-sdk/webar-sdk/webar-sdk-v2.0.8.min.js';
  error = signal(null);
  isIOS: boolean = false;
  private cameraStream: MediaStream | null = null;
  private videoElement: HTMLVideoElement | null = null;
  private sdkReady = false;

  constructor(private storageService: StorageService) {
    this.isiOSChecker();
  }

  public setVideoElement(element: HTMLVideoElement) {
    this.videoElement = element;
    if (this.cameraStream && this.videoElement) {
      this.videoElement.srcObject = this.cameraStream;
    }
  }

  public injectBlipparWebSDKtoDOM(): Observable<void> {
    return new Observable((observer) => {
      const script = document.createElement('script');
      script.src = this.scriptPath;
      script.async = true;

      // Set all the attributes
      script.setAttribute('webar-mode', 'surface-tracking');
      // script.setAttribute('on-progress', 'customProgressCallback');
      // script.setAttribute('on-error', 'customErrorCallback');
      script.setAttribute('auto-init', 'false');
      script.setAttribute('auto-start-tracking', 'true');
      script.setAttribute('minimal-ui', 'true');
      script.setAttribute('render-scene-on-desktop', 'false');
      script.setAttribute('external-camera-stream', 'true');
      script.setAttribute('debug-mode', 'false');
      script.onload = () => {
        this.SDK_Loaded.set(true);
        WEBARSDK.Init();

        WEBARSDK.SetAppReadyCallback(() => {
          this.sdkReady = true;
          this.tryInitializeSDK();
        });
        // Optionally handle video started callback for loading screen
        if (WEBARSDK.SetVideoStartedCallback) {
          WEBARSDK.SetVideoStartedCallback(() => {
            // Hide loading screen here if you have one
          });
        }
        observer.next();
        observer.complete();
      };

      script.onerror = () => {
        this.SDK_Loaded.set(false);
        this.error.set('Failed to load Blippar Web SDK');
        observer.error(this.error);
      };
      document.head.appendChild(script);
    });
  }

  public async askForPermissions(): Promise<void> {
    // 1. Request motion permissions (iOS only)
    if (
      this.isIOS &&
      typeof (window as any).DeviceMotionEvent?.requestPermission === 'function'
    ) {
      try {
        const permission = await (window as any).DeviceMotionEvent.requestPermission();
        if (permission !== 'granted') {
          this.error.set('Motion permission denied');
          throw new Error('Motion permission denied');
        }
      } catch (error) {
        this.error.set('Motion permission error: ' + error);
        throw error;
      }
    }

    // 2. Request camera permissions
    try {
      const devices = await navigator.mediaDevices.enumerateDevices();
      const videoDevices = devices.filter((d) => d.kind === 'videoinput');
      let constraints: MediaTrackConstraints = { facingMode: 'environment' };
      if (videoDevices.length > 0) {
        constraints.deviceId = videoDevices[videoDevices.length - 1].deviceId;
      }
      this.cameraStream = await navigator.mediaDevices.getUserMedia({
        video: constraints,
      });
      if (this.videoElement) {
        this.videoElement.srcObject = this.cameraStream;
      }
      this.tryInitializeSDK();
    } catch (error) {
      this.error.set('Camera permission denied or error: ' + error);
      throw error;
    }
  }

  private tryInitializeSDK() {
    // Only initialize when both SDK and camera are ready
    if (this.sdkReady && this.cameraStream) {
      try {
        WEBARSDK.SetCameraStream(this.cameraStream);
      } catch (err) {
        // Retry until SDK is ready
        setTimeout(() => this.tryInitializeSDK(), CAMERA_CONFIG.TIMING.SDK_RETRY_INTERVAL);
      }
    }
  }

  public isiOSChecker(): boolean {
    if (this.isIOS) return this.isIOS;
    let ua = navigator.userAgent.toLowerCase();
    if (this.storageService.getStorage('Platform', StorageType.cookiesStorage)) {
      ua = this.storageService.getStorage('Platform', StorageType.cookiesStorage).toLowerCase();
    }
    this.isIOS = ua.indexOf('iphone') > -1; // ios check
    return this.isIOS;
  }
}
